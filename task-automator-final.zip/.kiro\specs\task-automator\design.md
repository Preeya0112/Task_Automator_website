# Design Document

## Overview

The Task Automator is a web application built with Node.js and Express that provides a browser-based interface for automating common file operations. The application follows a client-server architecture where the frontend provides an intuitive UI for selecting operations and directories, while the backend handles file system operations safely and efficiently.

The system is designed with safety as a priority, implementing dry-run capabilities, input validation, and error handling to prevent accidental data loss. The architecture separates concerns between the web server, file operation logic, and the user interface to maintain modularity and testability.

## Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Web Browser                          │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              Frontend (HTML/CSS/JS)                   │  │
│  │  - Operation Forms                                    │  │
│  │  - Directory Browser                                  │  │
│  │  - Progress Display                                   │  │
│  │  - Results Viewer                                     │  │
│  └───────────────────────────────────────────────────────┘  │
└──────────────────────────┬──────────────────────────────────┘
                           │ HTTP/REST API
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                    Express Server (Port 4000)               │
│  ┌───────────────────────────────────────────────────────┐  │
│  │                  API Routes Layer                     │  │
│  │  - /api/browse                                        │  │
│  │  - /api/rename                                        │  │
│  │  - /api/organize                                      │  │
│  │  - /api/duplicates                                    │  │
│  └───────────────────────┬───────────────────────────────┘  │
│                          │                                   │
│  ┌───────────────────────▼───────────────────────────────┐  │
│  │              File Operations Service                  │  │
│  │  - RenameService                                      │  │
│  │  - OrganizeService                                    │  │
│  │  - DuplicateService                                   │  │
│  │  - ValidationService                                  │  │
│  └───────────────────────┬───────────────────────────────┘  │
│                          │                                   │
│  ┌───────────────────────▼───────────────────────────────┐  │
│  │              File System Utilities                    │  │
│  │  - Path validation                                    │  │
│  │  - File metadata reading                              │  │
│  │  - Safe file operations                               │  │
│  └───────────────────────────────────────────────────────┘  │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
                    Local File System
```

### Technology Stack

- **Backend**: Node.js with Express.js
- **Frontend**: Vanilla JavaScript with modern ES6+ features
- **File Operations**: Node.js `fs` and `path` modules
- **Hashing**: Node.js `crypto` module for duplicate detection

## Components and Interfaces

### 1. Web Server Component

**Responsibilities:**
- Start HTTP server on port 4000
- Serve static frontend files
- Route API requests to appropriate handlers
- Handle CORS and security headers

**Key Interfaces:**
```typescript
interface ServerConfig {
  port: number;
  staticDir: string;
}

function startServer(config: ServerConfig): void
```

### 2. API Routes Layer

**Responsibilities:**
- Define REST endpoints for file operations
- Parse and validate request parameters
- Return JSON responses with operation results

**Key Endpoints:**

```typescript
// Browse directory contents
GET /api/browse?path=<directory-path>
Response: {
  path: string;
  files: FileInfo[];
  directories: string[];
}

// Rename files
POST /api/rename
Body: {
  directory: string;
  pattern: string;
  fileTypes?: string[];
  dryRun: boolean;
}
Response: {
  success: boolean;
  operations: RenameOperation[];
  summary: OperationSummary;
}

// Organize files
POST /api/organize
Body: {
  directory: string;
  method: 'type' | 'date';
  dryRun: boolean;
}
Response: {
  success: boolean;
  operations: OrganizeOperation[];
  summary: OperationSummary;
}

// Find and manage duplicates
POST /api/duplicates
Body: {
  directory: string;
  action: 'scan' | 'remove';
  dryRun: boolean;
}
Response: {
  success: boolean;
  duplicateGroups: DuplicateGroup[];
  summary: OperationSummary;
}
```

### 3. File Operations Services

**RenameService:**
```typescript
interface RenameOptions {
  directory: string;
  pattern: string;
  fileTypes?: string[];
  dryRun: boolean;
}

interface RenameOperation {
  oldPath: string;
  newPath: string;
  status: 'pending' | 'success' | 'error';
  error?: string;
}

class RenameService {
  rename(options: RenameOptions): RenameOperation[];
  validatePattern(pattern: string): boolean;
  applyPattern(filename: string, pattern: string, index: number): string;
}
```

**OrganizeService:**
```typescript
interface OrganizeOptions {
  directory: string;
  method: 'type' | 'date';
  dryRun: boolean;
}

interface OrganizeOperation {
  sourcePath: string;
  targetPath: string;
  status: 'pending' | 'success' | 'error';
  error?: string;
}

class OrganizeService {
  organize(options: OrganizeOptions): OrganizeOperation[];
  organizeByType(directory: string, dryRun: boolean): OrganizeOperation[];
  organizeByDate(directory: string, dryRun: boolean): OrganizeOperation[];
}
```

**DuplicateService:**
```typescript
interface DuplicateGroup {
  hash: string;
  files: FileInfo[];
  totalSize: number;
}

interface DuplicateOptions {
  directory: string;
  action: 'scan' | 'remove';
  dryRun: boolean;
}

class DuplicateService {
  findDuplicates(directory: string): DuplicateGroup[];
  removeDuplicates(groups: DuplicateGroup[], dryRun: boolean): OrganizeOperation[];
  computeFileHash(filePath: string): string;
}
```

**ValidationService:**
```typescript
class ValidationService {
  validatePath(path: string): ValidationResult;
  isSystemPath(path: string): boolean;
  hasPermissions(path: string, operation: 'read' | 'write'): boolean;
  validatePattern(pattern: string): ValidationResult;
}

interface ValidationResult {
  valid: boolean;
  error?: string;
}
```

### 4. Frontend Components

**Directory Browser:**
- Displays directory tree
- Allows navigation through folders
- Shows file metadata (name, size, type, date)

**Operation Forms:**
- Rename form with pattern input
- Organize form with method selection
- Duplicate finder form
- Dry-run toggle for all operations

**Results Display:**
- Shows operation results in a table
- Displays summary statistics
- Shows errors and warnings
- Provides download option for operation logs

## Data Models

### FileInfo
```typescript
interface FileInfo {
  name: string;
  path: string;
  size: number;
  type: string;
  modifiedDate: Date;
  isDirectory: boolean;
}
```

### OperationSummary
```typescript
interface OperationSummary {
  totalOperations: number;
  successful: number;
  failed: number;
  skipped: number;
  spaceFreed?: number;
  foldersCreated?: number;
}
```

### OperationResult
```typescript
interface OperationResult {
  success: boolean;
  operations: Operation[];
  summary: OperationSummary;
  errors: ErrorInfo[];
}

interface ErrorInfo {
  path: string;
  operation: string;
  message: string;
}
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Pattern application consistency
*For any* set of files and valid naming pattern, applying the rename operation should result in all renamed files matching the specified pattern format.
**Validates: Requirements 1.1**

### Property 2: Sequential numbering order
*For any* set of files and pattern with sequential numbering, the applied numbers should be in strictly ascending order without gaps.
**Validates: Requirements 1.2**

### Property 3: File type filtering accuracy
*For any* set of files with mixed types and specified file type filter, only files matching the filter should be included in rename operations.
**Validates: Requirements 1.4**

### Property 4: Rename operation count accuracy
*For any* rename operation, the reported count of successfully renamed files should equal the actual number of files with changed names.
**Validates: Requirements 1.5**

### Property 5: Type-based organization correctness
*For any* set of files organized by type, each file should be located in a folder named after its file extension.
**Validates: Requirements 2.1**

### Property 6: Date-based organization correctness
*For any* set of files organized by date, each file should be located in a folder corresponding to its modification date.
**Validates: Requirements 2.2**

### Property 7: Metadata preservation invariant
*For any* file moved during organization, its size, modification date, and other metadata should remain identical before and after the move.
**Validates: Requirements 2.3**

### Property 8: Name conflict resolution
*For any* organization operation where target files already exist, the system should append unique identifiers to prevent any file overwrites.
**Validates: Requirements 2.4**

### Property 9: Organization operation count accuracy
*For any* organization operation, the reported counts of files moved and folders created should match the actual changes to the file system.
**Validates: Requirements 2.5**

### Property 10: Dry run immutability
*For any* operation executed in dry run mode, the file system state should remain completely unchanged after the operation completes.
**Validates: Requirements 3.1**

### Property 11: Dry run output completeness
*For any* dry run operation, the output should contain both before and after states for every planned file operation.
**Validates: Requirements 3.2**

### Property 12: Dry run summary accuracy
*For any* dry run operation, the summary count should equal the number of individual operations in the detailed output.
**Validates: Requirements 3.3**

### Property 13: Duplicate detection by content
*For any* set of files where multiple files have identical content, the duplicate detection should group exactly those files together based on hash comparison.
**Validates: Requirements 4.1**

### Property 14: Duplicate group structure
*For any* duplicate detection result, each group should contain at least two files with identical hashes and accurate size information.
**Validates: Requirements 4.2**

### Property 15: Duplicate removal completeness
*For any* set of duplicate groups, after removal operation, exactly one file from each group should remain in the file system.
**Validates: Requirements 4.3**

### Property 16: Duplicate preservation priority
*For any* duplicate group, the file that is preserved should be either the one with the shortest path or the most recent modification date.
**Validates: Requirements 4.4**

### Property 17: Duplicate removal reporting accuracy
*For any* duplicate removal operation, the reported number of files removed and space freed should match the actual changes to the file system.
**Validates: Requirements 4.5**

### Property 18: Invalid path rejection
*For any* invalid or non-existent directory path, all operations should be rejected with a clear error message before any file system access.
**Validates: Requirements 5.1**

### Property 19: System path protection
*For any* operation targeting system or protected directories, the system should prevent execution and return a warning.
**Validates: Requirements 5.2**

### Property 20: Invalid input validation
*For any* invalid pattern or parameter, the validation should fail before execution and return specific error details.
**Validates: Requirements 5.4**

### Property 21: API request validation
*For any* API request with valid inputs, the operation should execute successfully; for invalid inputs, the request should be rejected with appropriate error codes.
**Validates: Requirements 6.3**

### Property 22: API response structure
*For any* completed operation, the API response should include success status, operations list, summary statistics, and any errors or warnings.
**Validates: Requirements 6.5**

### Property 23: Directory listing validation
*For any* valid directory path, the browse endpoint should return contents; for invalid paths, it should return an error.
**Validates: Requirements 7.3**

### Property 24: Directory listing completeness
*For any* directory listing response, each file entry should include name, type, size, and modification date fields.
**Validates: Requirements 7.4**

## Error Handling

### Input Validation Errors
- Invalid directory paths: Return 400 Bad Request with specific error message
- Invalid patterns: Return 400 Bad Request with pattern syntax explanation
- Missing required parameters: Return 400 Bad Request with list of missing fields

### File System Errors
- Permission denied: Log error, skip file, continue with remaining operations
- File not found: Log error, mark operation as failed, continue
- Disk full: Abort operation, return 507 Insufficient Storage
- Path too long: Skip file, log warning, continue

### System Protection
- System directories (e.g., /System, C:\Windows): Block operation, return 403 Forbidden
- Protected files: Skip file, log warning, continue
- Symbolic links: Follow links but validate target paths

### Conflict Resolution
- Naming conflicts: Append timestamp or counter (e.g., file_1.txt, file_2.txt)
- Duplicate detection conflicts: Preserve file with shortest path or newest date
- Concurrent operations: Use file locking or queue operations

### Error Response Format
```typescript
interface ErrorResponse {
  success: false;
  error: {
    code: string;
    message: string;
    details?: any;
  };
}
```

## Testing Strategy

### Unit Testing

The application will use **Jest** as the testing framework for unit tests. Unit tests will focus on:

- **Service Layer Logic**: Test individual methods in RenameService, OrganizeService, DuplicateService, and ValidationService
- **Pattern Parsing**: Test pattern application and sequential numbering logic
- **Path Validation**: Test system path detection and permission checking
- **Hash Computation**: Test file hashing for duplicate detection
- **API Endpoints**: Test request parsing and response formatting
- **Error Handling**: Test specific error scenarios (permission denied, file not found, etc.)

Example unit tests:
- Test that pattern "photo_{n}.jpg" correctly generates "photo_1.jpg", "photo_2.jpg", etc.
- Test that system paths like "/System" are correctly identified and blocked
- Test that duplicate groups correctly identify files with matching hashes
- Test that conflict resolution appends unique identifiers

### Property-Based Testing

The application will use **fast-check** as the property-based testing library. Property-based tests will verify universal properties across randomly generated inputs:

- Each property-based test will run a minimum of 100 iterations
- Each test will be tagged with a comment referencing the correctness property from this design document
- Tag format: `// Feature: task-automator, Property {number}: {property_text}`
- Each correctness property will be implemented by a single property-based test

Property-based tests will cover:

- **Rename Operations**: Generate random file sets and patterns, verify all files match pattern
- **Sequential Numbering**: Generate random file counts, verify ascending order without gaps
- **File Type Filtering**: Generate mixed file types, verify filtering accuracy
- **Organization Operations**: Generate random files, verify correct folder placement
- **Metadata Preservation**: Verify file metadata unchanged after moves
- **Dry Run Immutability**: Verify file system unchanged for any dry run operation
- **Duplicate Detection**: Generate files with known duplicates, verify correct grouping
- **Input Validation**: Generate invalid inputs, verify rejection before execution
- **API Responses**: Verify response structure for any valid operation

### Integration Testing

Integration tests will verify end-to-end workflows:

- Start server, make API requests, verify responses
- Test complete rename workflow from directory selection to result display
- Test organization workflow with actual file creation and movement
- Test duplicate detection and removal with real files
- Test error handling with permission-restricted directories

### Test Data Management

- Use temporary directories for all file operation tests
- Clean up test files after each test run
- Generate test files with known properties (size, type, content)
- Use deterministic file names for reproducible tests

## Performance Considerations

### File System Operations
- Use asynchronous file operations to prevent blocking
- Implement batch processing for large directories (process in chunks of 100 files)
- Use streaming for hash computation on large files
- Cache directory listings to reduce repeated file system access

### Memory Management
- Avoid loading entire files into memory for hashing
- Use streams for file operations
- Limit concurrent operations to prevent memory exhaustion
- Implement pagination for large result sets

### Progress Reporting
- Report progress every 10% of operations completed
- Use WebSocket or Server-Sent Events for real-time updates
- Throttle progress updates to avoid overwhelming the client

### Scalability Limits
- Maximum files per operation: 10,000
- Maximum file size for hashing: 1GB
- Maximum directory depth: 20 levels
- Request timeout: 5 minutes for long operations

## Security Considerations

### Path Traversal Prevention
- Validate all paths to prevent directory traversal attacks
- Reject paths containing ".." or other suspicious patterns
- Use path.resolve() to normalize paths before validation
- Maintain whitelist of allowed base directories

### File System Access Control
- Run server with minimal required permissions
- Block operations on system directories
- Validate file permissions before operations
- Log all file operations for audit trail

### Input Sanitization
- Validate and sanitize all user inputs
- Limit pattern complexity to prevent ReDoS attacks
- Enforce maximum length limits on all string inputs
- Escape special characters in file names

### API Security
- Implement rate limiting to prevent abuse
- Add CSRF protection for state-changing operations
- Use HTTPS in production
- Validate Content-Type headers

## Deployment

### Development Setup
```bash
npm install
npm run dev  # Starts server on port 4000
```

### Production Build
```bash
npm run build
npm start
```

### Environment Variables
- `PORT`: Server port (default: 4000)
- `NODE_ENV`: Environment (development/production)
- `MAX_FILE_SIZE`: Maximum file size for operations (default: 1GB)
- `ALLOWED_PATHS`: Comma-separated list of allowed base directories

### System Requirements
- Node.js 18 or higher
- 512MB RAM minimum
- Read/write access to target directories
- Modern web browser (Chrome, Firefox, Safari, Edge)
