# Implementation Plan

- [ ] 1. Set up project structure and dependencies
  - Initialize Node.js project with package.json
  - Install Express, Jest, and fast-check dependencies
  - Create directory structure: src/, public/, tests/
  - Configure Jest for testing
  - _Requirements: 6.1_

- [ ] 2. Implement file system utilities
  - Create src/utils/fileSystem.js with utility functions
  - Implement getFileMetadata() to read file stats (name, size, type, date)
  - Implement listDirectory() to get directory contents with metadata
  - Implement path normalization and sanitization helpers
  - _Requirements: 7.3, 7.4_

- [ ]* 2.1 Write property test for directory listing validation
  - **Property 23: Directory listing validation**
  - **Validates: Requirements 7.3**

- [ ]* 2.2 Write property test for file metadata completeness
  - **Property 24: Directory listing completeness**
  - **Validates: Requirements 7.4**

- [ ] 3. Implement ValidationService
  - Create src/services/ValidationService.js
  - Implement validatePath() for directory validation
  - Implement isSystemPath() to detect protected directories (System, Windows, etc.)
  - Implement validatePattern() for rename pattern validation
  - Implement hasPermissions() for file access checking
  - _Requirements: 5.1, 5.2, 5.4_

- [ ]* 3.1 Write property test for invalid path rejection
  - **Property 18: Invalid path rejection**
  - **Validates: Requirements 5.1**

- [ ]* 3.2 Write property test for system path protection
  - **Property 19: System path protection**
  - **Validates: Requirements 5.2**

- [ ]* 3.3 Write property test for pattern validation
  - **Property 20: Invalid input validation**
  - **Validates: Requirements 5.4**

- [ ] 4. Implement RenameService
  - Create src/services/RenameService.js
  - Implement applyPattern() to transform filenames with {n} placeholder
  - Implement sequential numbering logic
  - Implement file type filtering
  - Implement detectConflicts() to check for naming conflicts
  - Implement rename() method with dry-run support
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5_

- [ ]* 4.1 Write property test for pattern application consistency
  - **Property 1: Pattern application consistency**
  - **Validates: Requirements 1.1**

- [ ]* 4.2 Write property test for sequential numbering order
  - **Property 2: Sequential numbering order**
  - **Validates: Requirements 1.2**

- [ ]* 4.3 Write property test for file type filtering accuracy
  - **Property 3: File type filtering accuracy**
  - **Validates: Requirements 1.4**

- [ ]* 4.4 Write property test for rename count accuracy
  - **Property 4: Rename operation count accuracy**
  - **Validates: Requirements 1.5**

- [ ] 5. Implement OrganizeService
  - Create src/services/OrganizeService.js
  - Implement organizeByType() to group files by extension
  - Implement organizeByDate() to group files by modification date
  - Implement moveFile() with metadata preservation
  - Implement conflict resolution with unique identifiers
  - Implement organize() method with dry-run support
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_

- [ ]* 5.1 Write property test for type-based organization correctness
  - **Property 5: Type-based organization correctness**
  - **Validates: Requirements 2.1**

- [ ]* 5.2 Write property test for date-based organization correctness
  - **Property 6: Date-based organization correctness**
  - **Validates: Requirements 2.2**

- [ ]* 5.3 Write property test for metadata preservation invariant
  - **Property 7: Metadata preservation invariant**
  - **Validates: Requirements 2.3**

- [ ]* 5.4 Write property test for name conflict resolution
  - **Property 8: Name conflict resolution**
  - **Validates: Requirements 2.4**

- [ ]* 5.5 Write property test for organization count accuracy
  - **Property 9: Organization operation count accuracy**
  - **Validates: Requirements 2.5**

- [ ] 6. Implement DuplicateService
  - Create src/services/DuplicateService.js
  - Implement computeFileHash() using crypto module with streaming
  - Implement findDuplicates() to scan directory and group by hash
  - Implement selectFileToKeep() logic (shortest path or newest date)
  - Implement removeDuplicates() with dry-run support
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_

- [ ]* 6.1 Write property test for duplicate detection by content
  - **Property 13: Duplicate detection by content**
  - **Validates: Requirements 4.1**

- [ ]* 6.2 Write property test for duplicate group structure
  - **Property 14: Duplicate group structure**
  - **Validates: Requirements 4.2**

- [ ]* 6.3 Write property test for duplicate removal completeness
  - **Property 15: Duplicate removal completeness**
  - **Validates: Requirements 4.3**

- [ ]* 6.4 Write property test for preservation priority
  - **Property 16: Duplicate preservation priority**
  - **Validates: Requirements 4.4**

- [ ]* 6.5 Write property test for removal reporting accuracy
  - **Property 17: Duplicate removal reporting accuracy**
  - **Validates: Requirements 4.5**

- [ ] 7. Implement dry-run functionality verification
  - Verify all service methods support dryRun flag
  - Ensure dry-run mode returns operation previews without executing
  - Implement operation summary generation for all services
  - _Requirements: 3.1, 3.2, 3.3_

- [ ]* 7.1 Write property test for dry-run immutability
  - **Property 10: Dry run immutability**
  - **Validates: Requirements 3.1**

- [ ]* 7.2 Write property test for dry-run output completeness
  - **Property 11: Dry run output completeness**
  - **Validates: Requirements 3.2**

- [ ]* 7.3 Write property test for dry-run summary accuracy
  - **Property 12: Dry run summary accuracy**
  - **Validates: Requirements 3.3**

- [ ] 8. Implement API routes
  - Create src/routes/api.js with Express router
  - Implement GET /api/browse endpoint with path parameter
  - Implement POST /api/rename endpoint
  - Implement POST /api/organize endpoint
  - Implement POST /api/duplicates endpoint
  - Add request validation middleware
  - Add error handling middleware
  - _Requirements: 6.3, 6.5_

- [ ]* 8.1 Write property test for API request validation
  - **Property 21: API request validation**
  - **Validates: Requirements 6.3**

- [ ]* 8.2 Write property test for API response structure
  - **Property 22: API response structure**
  - **Validates: Requirements 6.5**

- [ ] 9. Create Express server
  - Create src/server.js as entry point
  - Set up Express application with middleware (body-parser, CORS)
  - Mount API routes at /api
  - Configure static file serving for public/ directory
  - Implement server startup on port 4000
  - Add graceful shutdown handling
  - _Requirements: 6.1_

- [ ] 10. Build frontend HTML structure
  - Create public/index.html with semantic structure
  - Add directory browser section with file list
  - Add operation tabs (Rename, Organize, Duplicates)
  - Add forms for each operation with inputs and dry-run toggle
  - Add results display area with table
  - Add progress indicator elements
  - _Requirements: 6.2, 7.1_

- [ ] 11. Implement frontend JavaScript
  - Create public/app.js
  - Implement API client functions (browse, rename, organize, duplicates)
  - Implement directory browser with navigation and selection
  - Implement form submission handlers for all operations
  - Implement results rendering with operation details
  - Add progress indicator updates
  - Add error display handling
  - _Requirements: 6.2, 6.4, 6.5, 7.1, 7.2, 7.5_

- [ ] 12. Style frontend with CSS
  - Create public/styles.css
  - Create responsive layout with flexbox/grid
  - Style directory browser with file type icons
  - Style operation forms and tabs
  - Style results table with status indicators
  - Add loading animations and transitions
  - Ensure accessibility (ARIA labels, focus states, keyboard navigation)
  - _Requirements: 6.2_

- [ ] 13. Add error handling and user feedback
  - Display validation errors inline in forms
  - Show operation errors in results table
  - Add toast/notification system for success/error messages
  - Implement error recovery suggestions in error messages
  - Add confirmation dialogs for destructive operations (non-dry-run)
  - _Requirements: 5.1, 5.2, 5.4, 5.5, 6.5_

- [ ] 14. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [ ]* 15. Add integration tests
  - Create tests/integration/ directory
  - Test complete rename workflow end-to-end
  - Test complete organize workflow end-to-end
  - Test complete duplicate detection workflow
  - Test error scenarios with invalid inputs
  - Test server startup and API availability

- [ ] 16. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
